function res = logsample(st,en,stp);
res = logspace(log(st)/log(10),log(en)/log(10),stp);
